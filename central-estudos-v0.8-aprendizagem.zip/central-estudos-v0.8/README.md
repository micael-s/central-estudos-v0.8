# Central de Estudos — Versão 0.2

Projeto inicial real, modular e portátil para estudos de Transpetro e TCE-GO. **Não é a plataforma completa.**

## O que já funciona
- Dashboard com estatísticas obtidas do banco PostgreSQL.
- Biblioteca de matérias cadastradas.
- Questões de demonstração filtráveis por concurso, matéria e dificuldade.
- Correção com explicação e registro persistente de respostas.
- Painel inicial de desempenho.
- Nova aba **Estudar** com árvore de conceitos, explicações e exemplos práticos.
- 12 conceitos didáticos de demonstração distribuídos entre Banco de Dados, Segurança e Redes.
- Layout responsivo para celular e computador.

## O que ainda não funciona
- Login, contas e permissões; painel de administração funcional; importação de editais; questões oficiais; milhares de questões; simulados; revisões espaçadas; backups automáticos; acesso externo seguro.
- **Não publique esta versão na internet.** O banco e a API não possuem autenticação de usuários.

## Windows 10: instalação gráfica
1. Instale e inicie o Docker Desktop, se o computador atender aos requisitos do Docker/WSL2. Ative a virtualização caso seja solicitada. Se o Docker Desktop não for compatível, precisaremos escolher outra execução local.
2. Extraia este ZIP em uma pasta.
3. Renomeie `.env.example` para `.env` e altere `DB_PASSWORD` para uma senha forte, **antes do primeiro início**. O arquivo `INICIAR-WINDOWS.bat` copia o exemplo caso `.env` não exista, mas essa senha padrão é apenas para testes locais.
4. Clique duas vezes em `INICIAR-WINDOWS.bat`.
5. Abra `http://localhost:8080`.
6. Para interromper, clique em `PARAR-WINDOWS.bat`.

**Atenção:** se você alterar a senha do banco após o primeiro início, ela não muda automaticamente dentro do banco já criado. Nunca execute `docker compose down -v` sem backup, pois isso apaga o volume de dados.

## Arquitetura
- `frontend/`: React + TypeScript + Vite, servido pelo Nginx.
- `backend/`: Node.js + Express, API REST.
- `backend/sql/`: criação de tabelas e duas questões demonstrativas originais e árvore didática com 12 conceitos.
- `docker-compose.yml`: banco PostgreSQL, API e interface web.

A porta 8080 está ligada somente ao computador local (`127.0.0.1`), intencionalmente. Para hospedagem posterior em Debian e acesso remoto seguro, serão necessários autenticação, backup e configuração de rede/VPN.

## Próximas etapas
1. Autenticação e painel administrativo gráfico real.
2. Modelagem de editais, assuntos/subassuntos, origem das questões e vínculo múltiplo entre concursos.
3. Importação revisada de questões, com histórico por usuário.
4. Simulados, revisões e caderno de erros.
5. Backups/restauração e migração para Debian XFCE no notebook de 4 GB.

## Observação de conteúdo
As duas questões avaliativas presentes são **originais de demonstração**, não foram extraídas de provas oficiais. A lista de disciplinas é uma estrutura inicial sujeita à conferência do edital oficial e suas retificações.

## Atualização da versão 0.1 para 0.2 (sem perder as respostas)
1. Feche a página do navegador, mas **não exclua volumes do Docker**.
2. Faça backup da pasta do projeto antigo, especialmente do arquivo `.env`.
3. Extraia o ZIP v0.2 em outra pasta e copie o arquivo `.env` da v0.1 para a nova pasta.
4. Se a v0.1 estiver rodando, na pasta antiga clique em `PARAR-WINDOWS.bat`.
5. **Para preservar o banco existente**, mantenha o mesmo nome de projeto Docker Compose da versão anterior: execute ambas as versões a partir de pastas chamadas `central-estudos` (substitua os arquivos da pasta antiga após fazer backup, em vez de mudar o nome da pasta). Assim o volume PostgreSQL será reutilizado.
6. Clique em `INICIAR-WINDOWS.bat`. A criação de `study_nodes` é idempotente e mantém os dados existentes.
7. Se algo falhar, preserve o volume e envie uma captura da mensagem de erro. **Não use `docker compose down -v`.**

Esta versão ainda não oferece login nem acesso público.


## Atualização v0.3
- Mantém a mesma árvore de aprendizagem da v0.2 e adiciona pesquisa de conceitos.
- Administração local: criar matérias, perguntas explicadas (com ramificação) e questões de múltipla escolha.
- No arquivo `.env`, defina `ADMIN_KEY` com uma chave longa (mínimo 16 caracteres) além de `DB_PASSWORD`.
- Execute `INICIAR-WINDOWS.bat` novamente para reconstruir as imagens.
- **Não use na internet ainda:** não há login de usuários, proteção contra abuso, TLS nem controle de permissões por conta. O painel usa uma chave simples somente para uso local.
- **Preservação:** faça backup da pasta e do banco antes de atualizar; mantenha o mesmo nome do projeto/pasta Docker Compose e nunca execute `docker compose down -v`.
- Questões criadas pelo painel são identificadas como originais; não há importação de questões oficiais nesta versão.
