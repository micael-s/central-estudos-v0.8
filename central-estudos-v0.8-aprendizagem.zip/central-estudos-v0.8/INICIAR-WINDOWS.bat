@echo off
cd /d "%~dp0"
where docker >nul 2>nul
if errorlevel 1 (
 echo Docker Desktop nao encontrado. Instale Docker Desktop e abra o programa antes de tentar novamente.
 pause
 exit /b 1
)
if not exist .env copy .env.example .env >nul
echo Iniciando a plataforma. Na primeira vez, pode demorar alguns minutos...
docker compose up -d --build
if errorlevel 1 (
 echo Falha ao iniciar. Verifique se o Docker Desktop esta aberto.
 pause
 exit /b 1
)
start http://localhost:8080
echo Plataforma iniciada em http://localhost:8080
pause
