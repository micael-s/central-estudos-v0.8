CREATE TABLE IF NOT EXISTS exams (id SERIAL PRIMARY KEY, name TEXT NOT NULL UNIQUE, board TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS subjects (id SERIAL PRIMARY KEY, name TEXT NOT NULL UNIQUE);
CREATE TABLE IF NOT EXISTS questions (id SERIAL PRIMARY KEY, subject_id INTEGER NOT NULL REFERENCES subjects(id), exam_id INTEGER NOT NULL REFERENCES exams(id), topic TEXT NOT NULL, statement TEXT NOT NULL, options JSONB NOT NULL, correct_index INTEGER NOT NULL CHECK (correct_index BETWEEN 0 AND 4), explanation TEXT NOT NULL, difficulty TEXT NOT NULL CHECK (difficulty IN ('Normal','Avançado')), origin TEXT NOT NULL DEFAULT 'original', source_note TEXT NOT NULL DEFAULT 'Questão demonstrativa original');
CREATE TABLE IF NOT EXISTS attempts (id BIGSERIAL PRIMARY KEY, question_id INTEGER NOT NULL REFERENCES questions(id), selected_index INTEGER NOT NULL, correct BOOLEAN NOT NULL, answered_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
INSERT INTO exams(name,board) VALUES ('Transpetro - Segurança Cibernética','Cesgranrio'),('TCE-GO - Tecnologia da Informação','FCC') ON CONFLICT DO NOTHING;
INSERT INTO subjects(name) VALUES ('Segurança da Informação'),('Banco de Dados'),('Redes de Computadores'),('Engenharia de Software'),('Português'),('Matemática e Raciocínio Lógico'),('Legislação'),('Inglês Técnico'),('Governança de TI'),('Desenvolvimento de Sistemas'),('DevOps'),('Inteligência Artificial') ON CONFLICT DO NOTHING;
INSERT INTO questions(subject_id,exam_id,topic,statement,options,correct_index,explanation,difficulty,origin,source_note)
SELECT s.id,e.id,'Princípios de segurança','Qual propriedade da segurança da informação busca impedir alterações não autorizadas nos dados?', '["Disponibilidade","Integridade","Confidencialidade","Escalabilidade","Portabilidade"]'::jsonb,1,'Integridade protege contra modificações indevidas. Confidencialidade limita o acesso e disponibilidade garante acesso quando necessário.','Normal','original','Exemplo original para teste — não é questão oficial' FROM subjects s,exams e WHERE s.name='Segurança da Informação' AND e.name LIKE 'Transpetro%' AND NOT EXISTS(SELECT 1 FROM questions);
INSERT INTO questions(subject_id,exam_id,topic,statement,options,correct_index,explanation,difficulty,origin,source_note)
SELECT s.id,e.id,'SQL','Qual cláusula SQL é usada para filtrar grupos após uma operação GROUP BY?', '["WHERE","ORDER BY","HAVING","LIMIT","JOIN"]'::jsonb,2,'HAVING filtra grupos agregados; WHERE filtra linhas antes do agrupamento.','Normal','original','Exemplo original para teste — não é questão oficial' FROM subjects s,exams e WHERE s.name='Banco de Dados' AND e.name LIKE 'TCE-GO%' AND NOT EXISTS(SELECT 1 FROM questions WHERE topic='SQL');

-- v0.2: material didatico separado das questoes avaliativas.
CREATE TABLE IF NOT EXISTS study_nodes (
 id TEXT PRIMARY KEY, subject_id INTEGER NOT NULL REFERENCES subjects(id),
 parent_id TEXT REFERENCES study_nodes(id), title TEXT NOT NULL,
 explanation TEXT NOT NULL, example TEXT NOT NULL DEFAULT '',
 sort_order INTEGER NOT NULL DEFAULT 0, origin TEXT NOT NULL DEFAULT 'original-demonstrativo'
);
INSERT INTO study_nodes(id,subject_id,parent_id,title,explanation,example,sort_order)
SELECT v.id,s.id,v.parent_id,v.title,v.explanation,v.example,v.sort_order
FROM (VALUES
 ('sql','Banco de Dados',NULL::text,'O que é SQL?','SQL é uma linguagem para consultar e manipular dados em bancos relacionais. Ela permite selecionar, inserir, alterar e remover registros.','SELECT nome FROM funcionarios;',1),
 ('select','Banco de Dados','sql','O que faz SELECT?','SELECT define quais colunas ou expressões uma consulta retorna. Pode ser combinado com filtros e ordenação.','SELECT nome, setor FROM funcionarios;',1),
 ('group-by','Banco de Dados','sql','Para que serve GROUP BY?','GROUP BY reúne linhas com valores iguais em colunas indicadas, permitindo calcular agregações por grupo.','SELECT setor, COUNT(*) FROM funcionarios GROUP BY setor;',2),
 ('having','Banco de Dados','group-by','O que é HAVING?','HAVING filtra grupos depois do agrupamento. É comum utilizá-lo com funções como COUNT e SUM.','SELECT setor, COUNT(*) FROM funcionarios GROUP BY setor HAVING COUNT(*) > 5;',1),
 ('where','Banco de Dados','group-by','Qual a diferença entre WHERE e HAVING?','WHERE filtra linhas antes do agrupamento. HAVING filtra grupos após o agrupamento.','SELECT setor, COUNT(*) FROM funcionarios WHERE ativo = true GROUP BY setor HAVING COUNT(*) > 5;',2),
 ('count','Banco de Dados','group-by','Para que serve COUNT?','COUNT(*) conta linhas de um grupo. COUNT(coluna) conta valores não nulos dessa coluna.','SELECT setor, COUNT(*) FROM funcionarios GROUP BY setor;',3),
 ('seguranca','Segurança da Informação',NULL::text,'O que é Segurança da Informação?','É o conjunto de práticas que protege informações contra acesso, alteração e indisponibilidade indevidos.','Uma empresa usa controles de acesso, backups e auditoria.',1),
 ('cid','Segurança da Informação','seguranca','O que é a tríade CID?','Confidencialidade limita acesso; Integridade protege contra alterações indevidas; Disponibilidade garante acesso quando necessário.','Um backup ajuda na disponibilidade; controle de permissões ajuda na confidencialidade.',1),
 ('autenticacao','Segurança da Informação','seguranca','O que é autenticação?','É a verificação da identidade de uma pessoa ou sistema. Não deve ser confundida com autorização, que determina permissões.','Senha e segundo fator podem autenticar um usuário.',2),
 ('redes','Redes de Computadores',NULL::text,'O que são redes de computadores?','São dispositivos conectados para trocar dados por meio de protocolos de comunicação.','Computadores de uma casa se conectam ao roteador para acessar serviços.',1),
 ('dns','Redes de Computadores','redes','Para que serve o DNS?','DNS resolve nomes de domínio em registros como endereços IP.','Ao acessar um domínio, o dispositivo consulta o DNS para localizar seu endereço.',1),
 ('tcp','Redes de Computadores','redes','Qual a diferença entre TCP e UDP?','TCP oferece transporte orientado à conexão com mecanismos de entrega confiável. UDP é baseado em datagramas e não garante entrega ou ordenação.','Uma aplicação pode usar TCP para transferir arquivos e UDP para comunicação sensível à latência.',2)
) AS v(id,subject,parent_id,title,explanation,example,sort_order)
JOIN subjects s ON s.name=v.subject
ON CONFLICT(id) DO NOTHING;

-- v0.8: cronograma persistente; mantém intactos os dados existentes.
CREATE TABLE IF NOT EXISTS study_plan (
 id BIGSERIAL PRIMARY KEY, study_date DATE NOT NULL, subject_id INTEGER NOT NULL REFERENCES subjects(id),
 minutes INTEGER NOT NULL CHECK(minutes BETWEEN 10 AND 600),notes TEXT NOT NULL DEFAULT '',completed BOOLEAN NOT NULL DEFAULT FALSE
);
CREATE INDEX IF NOT EXISTS idx_attempts_question_date ON attempts(question_id,answered_at DESC);
